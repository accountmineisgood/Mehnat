#!/usr/bin/env bash

python3 Bot/bot.py "$@"